bash install.ruby.sh
bash install_mongo.sh
bash deploy_app.sh
